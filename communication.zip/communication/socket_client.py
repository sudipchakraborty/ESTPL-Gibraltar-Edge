import socketio


class SocketClient:

    def __init__(self, server_url):

        self.sio = socketio.Client()

        self.server_url = server_url

    def connect(self):

        self.sio.connect(self.server_url)

        print("Connected to Backend")

    def disconnect(self):

        self.sio.disconnect()

    def send_detection(self, detection):

        self.sio.emit("detection", detection)
