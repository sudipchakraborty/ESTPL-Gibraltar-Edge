from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from pydantic import BaseModel

from aiortc import (
    RTCPeerConnection,
    RTCSessionDescription
)

from communication.video_track import ProcessedVideoTrack


class Offer(BaseModel):

    sdp: str
    type: str


class WebRTCServer:

    def __init__(self, camera_processor):

        self.camera_processor = camera_processor

        self.app = FastAPI()

        self.peer_connections = set()

        self._configure_cors()
        self._configure_routes()


    def _configure_cors(self):

        self.app.add_middleware(
            CORSMiddleware,

            allow_origins=["*"],

            allow_credentials=True,

            allow_methods=["*"],

            allow_headers=["*"]
        )


    def _configure_routes(self):

        @self.app.get("/")
        async def root():

            return {
                "status": "running",
                "service": "DeepVision WebRTC Server"
            }


        @self.app.post("/offer")
        async def offer(data: Offer):

            print("Received WebRTC offer")

            pc = RTCPeerConnection()

            self.peer_connections.add(pc)


            # Create processed video track
            video_track = ProcessedVideoTrack(
                self.camera_processor
            )

            pc.addTrack(video_track)


            @pc.on("connectionstatechange")
            async def on_connectionstatechange():

                print(
                    "WebRTC state:",
                    pc.connectionState
                )

                if pc.connectionState in [
                    "failed",
                    "closed"
                ]:

                    await pc.close()

                    self.peer_connections.discard(pc)


            # Browser offer
            remote_offer = RTCSessionDescription(
                sdp=data.sdp,
                type=data.type
            )

            await pc.setRemoteDescription(
                remote_offer
            )


            # Python answer
            answer = await pc.createAnswer()

            await pc.setLocalDescription(answer)


            print("Sending WebRTC answer")


            return {

                "sdp": pc.localDescription.sdp,

                "type": pc.localDescription.type

            }
